#!/bin/sh
echo Starting the ws-h5 robot tool
java -server -Xms128m -Xmx128m -Xmn48m  -XX:MaxDirectMemorySize=64m -XX:+UseParNewGC -XX:+UseConcMarkSweepGC -XX:+PrintGCDetails -XX:+PrintGCDateStamps -XX:+PrintGCApplicationStoppedTime -XX:+HeapDumpOnOutOfMemoryError -Xloggc:log/gc_$(date +"%Y%m%d%H%M").log -jar $PWD/gamioo-robot.jar 1 1  &
