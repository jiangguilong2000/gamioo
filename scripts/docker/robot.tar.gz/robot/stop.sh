#!/bin/sh
echo stoping the h5client server
pkill -f  $PWD/gamioo-robot.jar
